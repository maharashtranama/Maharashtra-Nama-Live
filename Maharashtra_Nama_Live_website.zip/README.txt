Maharashtra Nama Live - Free Starter Website

1. index.html ही मुख्य वेबसाइट फाइल आहे.
2. तुमचा लोगो जोडण्यासाठी index.html मधील "तुमचा LOGO" असलेला भाग बदलता येईल.
3. नवीन बातम्या टाकण्यासाठी HTML मधील नमुना headline/text बदलायचा.
4. फ्री hosting साठी GitHub Pages किंवा Netlify वापरता येईल.
5. maharashtranamalive.in हे custom domain वेगळे खरेदी/नोंदणी करून जोडता येईल.
